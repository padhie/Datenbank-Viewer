<?php
class AdminerKahiSkin {

	function head () {
		echo '
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.js"></script>
<script>window.jQuery || document.write("<script src=\'adminer-plus/js/jquery.min.js\'>\x3C/script>")</script>
<script src="adminer-plus/js/jquery.cookie.js"></script>
<script src="adminer-plus/js/my.js"></script>
';
	}

}