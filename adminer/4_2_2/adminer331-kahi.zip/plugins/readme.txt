../adminer/plugin.php - demo usage
http://www.adminer.org/en/plugins/ - documentation
